<?php

use Hex\JapaneseCrawler\App\Core\Kernel;

require_once '../vendor/autoload.php';

Kernel::new()->boot();